package cis112_week02.lab;

import java.awt.Color;

public class MovableMain {

	public static void main(String[] args) {
		MovableInterface[] movable = defineMovables();
		MovableGame movableGame = new MovableGame();
		movableGame.setMovable(movable);
		movableGame.run();
	}

	private static MovableInterface[] defineMovables() {
		final int SIZE = 5;
//		final int SIZE = 2;
		MovableInterface[] movable = new MovableInterface[SIZE];

		MovableShape movableShape;
		MovableCar car;
		MovableRectangle movableRectangle;
		MovableSquare movableSquare;

		// define the shapes
		int c = 0; // use of c as counter
		//
		movableShape = new MovableShape(30, 50);
		movableShape.setXY(10, 10);
		movableShape.setWH(20, 40);
		movableShape.setVelocity(10, 10);
		movableShape.setColor(Color.BLUE);
		movable[c++] = movableShape;
		//
		movableShape = new MovableShape();
		movableShape.setXY(350, 20);
		movableShape.setWH(30, 50);
		movableShape.setVelocity(-12, 10);
		movableShape.setColor(Color.ORANGE);
		movable[c++] = movableShape;
		//
		car = new MovableCar(100, 100, 50, 30, Color.RED);
		car.setVelocity(5, 8);
		movable[c++] = car;
		//
		movableRectangle = new MovableRectangle(new Point(40, 40), new Point(60, 50));
		movableRectangle.setVelocity(10, 15);
		movableRectangle.setColor(Color.CYAN);
		movable[c++] = movableRectangle;
		//
		movableSquare = new MovableSquare(new Point(60, 30), new Point(80, 30));
		movableSquare.setVelocity(14, 12);
		movableSquare.setColor(Color.PINK);
		movable[c++] = movableSquare;

		//
		return movable;
	}

}
