package cis112_week02.lab;

import java.awt.Color;
import java.awt.Graphics;

public class MovableShape implements MovableInterface {

	int x; // x of upper-left corner
	int y; // y of upper-left corner
	int width = 20;
	int height = 40;
	int velocityX = 4;
	int velocityY = 5;

	public MovableShape() {
		this(50, 80);
	}

	public MovableShape(int x, int y) {
		this.x = x;
		this.y = y;
	}

	Color color = Color.BLACK;

	public void setColor(Color color) {
		this.color = color;
	}

	@Override
	public void draw(Graphics g) {
		g.setColor(color);
		g.fillRect(x, y, width, height);
	}

	@Override
	public void move() {
		x += velocityX;
		y += velocityY;
	}

	@Override
	public void setVelocity(int velocityX, int velocityY) {
		this.velocityX = velocityX;
		this.velocityY = velocityY;
	}

	public void setXY(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public void setWH(int width, int height) {
		this.width = width;
		this.height = height;
	}

	public BoundingBox boundingBox() {
		// below-0123456789-V toDo // do not change this line ~~~~~~~~~~ V
		// TODO your code should be between below and above marks.

		 return new BoundingBox(0, 0, 0, 0); // ~~fake~~

		// above-0123456789-A toDo // do not change this line ~~~~~~~~~~ A
	}

	@Override
	public String canonical() {
		return toString();
	}

	@Override
	public String toString() {
		return "[MovableShape: x=" + x + ", y=" + y + ", width=" + width + ", height=" + height//
				+ ", velocityX=" + velocityX + ", velocityY=" + velocityY + ", color=" + color + "]";
	}

}
