package cis112_week02.lab;

import java.awt.Color;
import java.awt.Graphics;

public class MovableRectangle extends Rectangle implements MovableInterface {

	Color color;
	int velocityX = 2;
	int velocityY = 5;

	public MovableRectangle(Point pA, Point pC) {
		super(pA, pC);
	}

	@Override
	public void draw(Graphics g) {
		// below-0123456789-V toDo // do not change this line ~~~~~~~~~~ V
		// TODO your code should be between below and above marks.


		// above-0123456789-A toDo // do not change this line ~~~~~~~~~~ A
	}

	@Override
	public void move() {
		// below-0123456789-V toDo // do not change this line ~~~~~~~~~~ V
		// TODO your code should be between below and above marks.


		// above-0123456789-A toDo // do not change this line ~~~~~~~~~~ A
	}

	@Override
	public void setVelocity(int velocityX, int velocityY) {
		this.velocityX = velocityX;
		this.velocityY = velocityY;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	@Override
	public String toString() {
		return "[MovableRectangle: " + boundingBox().canonical()//
				+ ", velocityX=" + velocityX + ", velocityY=" + velocityY + "color=" + color + "]";
	}

	@Override
	public String canonical() {
		return toString();
	}

}
