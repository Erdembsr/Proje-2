package cis112_week02.lab;

public class BoundingBox {

	// in computer graphics (CG)
	// X-axis increase to the right
	// Y-axis increase to the down
	double x; // x of upper-left corner in CG
	double y; // y of upper-left corner in CG
	double width;
	double height;

	public BoundingBox(double x, double y, double width, double height) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

	public double getWidth() {
		return width;
	}

	public double getHeight() {
		return height;
	}

	public String canonical() {
		return "[BoundingBox: x=" + x + ", y=" + y + ", width=" + width + ", height=" + height + "]";
	}

	/**
	 * Checks if there is a common point.
	 * 
	 * @param a The first BoundingBox.
	 * @param b The second BoundingBox.
	 * @return true if there is a common point.
	 */
	public static boolean isOverlapped(BoundingBox a, BoundingBox b) {
		// below-0123456789-V toDo // do not change this line ~~~~~~~~~~ V
		// TODO your code should be between below and above marks.

		 return false; // ~~fake~~

		// above-0123456789-A toDo // do not change this line ~~~~~~~~~~ A
	}
}
