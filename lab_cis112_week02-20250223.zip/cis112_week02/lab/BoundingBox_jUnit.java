package cis112_week02.lab;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.MethodName.class)

class BoundingBox_jUnit {

	private static final boolean DEBUG = true;

	static final double EPSILON = 1e-10;

	final Point pA = new Point(0, 0);
	final Point pB = new Point(6, 0);
	final Point pC = new Point(9, 4);
	final Point pD = new Point(3, 4);
	final Point pE = new Point(6, 4);
	final Point pF = new Point(0, 4);

	@Test
	void collision_A() {
		System.out.println("\n-" + StackWalker.getInstance().walk(s -> s.skip(0).findFirst()).get().getMethodName());

		BoundingBox a = new BoundingBox(0, 0, 10, 10);
		BoundingBox b = new BoundingBox(1, 1, 10, 10);

		boolean expected = true;
		boolean actual = BoundingBox.isOverlapped(a, b);
		if (DEBUG) {
			System.out.println("expected:" + expected);
			System.out.println("actual  :" + actual);
		}
		assertEquals(expected, actual);
	}

	@Test
	void collision_B() {
		System.out.println("\n-" + StackWalker.getInstance().walk(s -> s.skip(0).findFirst()).get().getMethodName());

		BoundingBox a = new BoundingBox(0, 0, 10, 10);
		BoundingBox b = new BoundingBox(9, 9, 10, 10);

		boolean expected = true;
		boolean actual = BoundingBox.isOverlapped(a, b);
		if (DEBUG) {
			System.out.println("expected:" + expected);
			System.out.println("actual  :" + actual);
		}
		assertEquals(expected, actual);
	}

	@Test
	void collision_C() {
		System.out.println("\n-" + StackWalker.getInstance().walk(s -> s.skip(0).findFirst()).get().getMethodName());

		BoundingBox a = new BoundingBox(0, 0, 10, 10);
		BoundingBox b = new BoundingBox(2, 2, 4, 4);

		boolean expected = true;
		boolean actual = BoundingBox.isOverlapped(a, b);
		if (DEBUG) {
			System.out.println("expected:" + expected);
			System.out.println("actual  :" + actual);
		}
		assertEquals(expected, actual);
	}

	@Test
	void collisionNo_A() {
		System.out.println("\n-" + StackWalker.getInstance().walk(s -> s.skip(0).findFirst()).get().getMethodName());

		BoundingBox a = new BoundingBox(0, 0, 10, 10);
		BoundingBox b = new BoundingBox(11, 11, 10, 10);

		boolean expected = false;
		boolean actual = BoundingBox.isOverlapped(a, b);
		if (DEBUG) {
			System.out.println("expected:" + expected);
			System.out.println("actual  :" + actual);
		}
		assertEquals(expected, actual);
	}

	@Test
	void collisionNo_B() {
		System.out.println("\n-" + StackWalker.getInstance().walk(s -> s.skip(0).findFirst()).get().getMethodName());

		BoundingBox a = new BoundingBox(0, 0, 10, 10);
		BoundingBox b = new BoundingBox(11, 11, 10, 10);

		boolean expected = false;
		boolean actual = BoundingBox.isOverlapped(a, b);
		if (DEBUG) {
			System.out.println("expected:" + expected);
			System.out.println("actual  :" + actual);
		}
		assertEquals(expected, actual);
	}

	@Test
	void collisionNo_C() {
		System.out.println("\n-" + StackWalker.getInstance().walk(s -> s.skip(0).findFirst()).get().getMethodName());

		BoundingBox a = new BoundingBox(0, 0, 10, 10);
		BoundingBox b = new BoundingBox(11, 0, 10, 10);

		boolean expected = false;
		boolean actual = BoundingBox.isOverlapped(a, b);
		if (DEBUG) {
			System.out.println("expected:" + expected);
			System.out.println("actual  :" + actual);
		}
		assertEquals(expected, actual);
	}

}
