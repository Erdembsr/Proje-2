package cis112_week02.lab;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.MethodName.class)

class Square_jUnit {

	private static final boolean DEBUG = true;
	
	static final double EPSILON = 1e-10;

	final Point pA = new Point(0, 0);
	final Point pB = new Point(6, 0);
	final Point pC = new Point(9, 4);
	final Point pD = new Point(3, 4);
	final Point pE = new Point(6, 4);
	final Point pF = new Point(0, 4);

	@Test
	void circumference_ABEF() {
		System.out.println("\n-" + StackWalker.getInstance().walk(s -> s.skip(0).findFirst()).get().getMethodName());

		Square sABEF = new Square(pA, pB);
		double expected = 24;
		double actual = sABEF.getPerimeter();
		/**/System.out.println(actual);
		assertEquals(expected, actual, EPSILON);
	}

	@Test
	void area_ABEF() {
		System.out.println("\n-" + StackWalker.getInstance().walk(s -> s.skip(0).findFirst()).get().getMethodName());
	
		Square sABEF = new Square(pA, pB);
		double expected = 36;
		double actual = sABEF.getArea();
		/**/System.out.println(actual);
		assertEquals(expected, actual, EPSILON);
	}

	@Test
	void boundingBox_ABEF() {
		System.out.println("\n-" + StackWalker.getInstance().walk(s -> s.skip(0).findFirst()).get().getMethodName());

		Square sq = new Square(pA, pB);
		BoundingBox expected = new BoundingBox(//
				sq.getpD().x, //
				sq.getpD().y, //
				sq.getpD().distance(sq.getpC()), //
				sq.getpD().distance(sq.getpA())//
		);
		BoundingBox actual = sq.boundingBox();
		if (DEBUG) {
			System.out.println("expected:" + expected.canonical());
			System.out.println("actual  :" + actual.canonical());
		}
		assertEquals(expected.canonical(), actual.canonical());
	}

}
