package cis112_week02.lab;

import java.awt.*;

public class MovableCar implements MovableInterface {

	private int x;
	private int y;
	private int width;
	private int height;
	private int velocityX = 2; // Initial velocity in the X direction
	private int velocityY = 1; // Initial velocity in the Y direction

	private Color color;

	public MovableCar(int x, int y, int width, int height, Color color) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.color = color;
	}

	@Override
	public void draw(Graphics g) {
		g.setColor(color);
		g.fillRect(x, y, width, height); // MovableCar body
		g.setColor(Color.BLACK);
		g.fillOval(x + 5, y + height - 15, 15, 15); // Wheels
		g.fillOval(x + width - 20, y + height - 15, 15, 15);
	}

	@Override
	public void move() {
		x += velocityX;
		y += velocityY;
	}

	@Override
	public void setVelocity(int velocityX, int velocityY) {
		this.velocityX = velocityX;
		this.velocityY = velocityY;
	}

	@Override
	public BoundingBox boundingBox() {
		// TODO not correct
		return new BoundingBox(0,0,0,0);
	}

	@Override
	public String toString() {
		return "[MovableCar: x=" + x + ", y=" + y + ", width=" + width + ", height=" + height + ", velocityX="
				+ velocityX + ", velocityY=" + velocityY + ", color=" + color + "]";
	}

	@Override
	public String canonical() {
		return toString();
	}

}