package cis112_week02.lab;

import javax.swing.*;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * Simulator for generic game
 * 
 * @author bingol
 */
public class MovableGame extends JPanel implements KeyListener {

	private static final long serialVersionUID = 1L;

	private static final boolean DEBUG = true;

	private MovableInterface[] movable;
	private boolean oneMoreCycle = true;

	public MovableGame() {
		setPreferredSize(new Dimension(800, 600));
		setBackground(Color.WHITE);
		setFocusable(true);
		addKeyListener(this);
	}

	public void setMovable(MovableInterface[] movable) {
		this.movable = movable;
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		for (int i = 0; i < movable.length; i++) {
			movable[i].draw(g);
		}
	}

	public void update() {
		for (int i = 0; i < movable.length; i++) {
			movable[i].move();
		}
		repaint();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		int key = e.getKeyCode();
		switch (key) {
		case KeyEvent.VK_Q: // user quits
			System.out.println("User quits the game.");
			System.exit(ABORT);
			break;
		default:
			break;
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// nop
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// nop
	}

	public void run() {
		// prepare visible window
		JFrame frame = new JFrame("GenericGameFrame");
		frame.add(this);
		frame.pack();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

		System.out.println("Use Q to quit.\n");

		// Game loop
//		while (true) {
		int t = 0; // time
		while (oneMoreCycle && t < 30) {
			t++;
			System.out.println("time:" + t);

			update();
			checkCollision();

			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		System.out.println("  **** Game over");
	}

	public void checkCollision() {
		boolean collision = false;

		// below-0123456789-V toDo // do not change this line ~~~~~~~~~~ V
		// TODO your code should be between below and above marks.


		// above-0123456789-A toDo // do not change this line ~~~~~~~~~~ A

	}

}
