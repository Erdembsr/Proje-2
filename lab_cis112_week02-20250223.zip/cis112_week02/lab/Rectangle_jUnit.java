package cis112_week02.lab;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.MethodName.class)

class Rectangle_jUnit {

	private static final boolean DEBUG = true;

	static final double EPSILON = 1e-10;

	final Point pA = new Point(0, 0);
	final Point pB = new Point(6, 0);
	final Point pC = new Point(9, 4);
	final Point pD = new Point(3, 4);
	final Point pE = new Point(6, 4);
	final Point pF = new Point(0, 4);

	@Test
	void circumference_ABEF() {
		System.out.println("\n-" + StackWalker.getInstance().walk(s -> s.skip(0).findFirst()).get().getMethodName());
	
		Rectangle rABEF = new Rectangle(pA, pE);
		double expected = 20;
		double actual = rABEF.getPerimeter();
		System.out.println(actual);
		/**/System.out.println(actual);
		assertEquals(expected, actual, EPSILON);
	}

	@Test
	void area_ABCD() {
		System.out.println("\n-" + StackWalker.getInstance().walk(s -> s.skip(0).findFirst()).get().getMethodName());
	
		Rectangle rABEF = new Rectangle(pA, pE);
		double expected = 24;
		double actual = rABEF.getArea();
		/**/System.out.println(actual);
		assertEquals(expected, actual, EPSILON);
	}

	@Test
	void boundingBox_ABCD() {
		System.out.println("\n-" + StackWalker.getInstance().walk(s -> s.skip(0).findFirst()).get().getMethodName());
	
		Rectangle rec = new Rectangle(new Point(3, 0), pE);
		BoundingBox expected = new BoundingBox(//
				rec.getpD().x, //
				rec.getpD().y, //
				rec.getpD().distance(rec.getpC()), //
				rec.getpD().distance(rec.getpA())//
		);
		BoundingBox actual = rec.boundingBox();
		if (DEBUG) {
			System.out.println("expected:" + expected.canonical());
			System.out.println("actual  :" + actual.canonical());
		}
		assertEquals(expected.canonical(), actual.canonical());
	}

}
