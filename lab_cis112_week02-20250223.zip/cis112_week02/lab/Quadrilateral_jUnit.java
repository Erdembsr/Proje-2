package cis112_week02.lab;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.MethodName.class)

class Quadrilateral_jUnit {

	private static final boolean DEBUG = true;

	static final double EPSILON = 1e-10;

	final Point pA = new Point(0, 0);
	final Point pB = new Point(6, 0);
	final Point pC = new Point(9, 4);
	final Point pD = new Point(3, 4);
	final Point pE = new Point(6, 4);
	final Point pF = new Point(0, 4);

	@Test
	void circumference_ABCD() {
		System.out.println("\n-" + StackWalker.getInstance().walk(s -> s.skip(0).findFirst()).get().getMethodName());
	
		Quadrilateral qABCD = new Quadrilateral(pA, pB, pC, pD);
		double expected = 22;
		double actual = qABCD.getPerimeter();
		/**/System.out.println(actual);
		assertEquals(expected, actual, EPSILON);
	}

	@Test
	void area_ABCD() {
		System.out.println("\n-" + StackWalker.getInstance().walk(s -> s.skip(0).findFirst()).get().getMethodName());
	
		Quadrilateral qABCD = new Quadrilateral(pA, pB, pC, pD);
		double expected = 24;
		double actual = qABCD.getArea();
		/**/System.out.println(actual);
		assertEquals(expected, actual, EPSILON);
	}

	@Test
	void boundingBox_ABCD() {
		System.out.println("\n-" + StackWalker.getInstance().walk(s -> s.skip(0).findFirst()).get().getMethodName());
	
		Quadrilateral qABCD = new Quadrilateral(pA, pB, pC, pD);

		double aX[] = { qABCD.getpA().x, qABCD.getpB().x, qABCD.getpC().x, qABCD.getpD().x };
		double aY[] = { qABCD.getpA().y, qABCD.getpB().y, qABCD.getpC().y, qABCD.getpD().y };
		Arrays.sort(aX);
		Arrays.sort(aY);
		double minX = aX[0];
		double minY = aY[0];
		double maxX = aX[aX.length - 1];
		double maxY = aY[aY.length - 1];

		BoundingBox expected = new BoundingBox(minX, minY, maxX - minX, maxY - minY);
		BoundingBox actual = qABCD.boundingBox();
		if (DEBUG) {
			System.out.println("minX:" + minX + " maxX:" + maxX);
			System.out.println("minY:" + minY + " maxY:" + maxY);
			System.out.println("expected:" + expected.canonical());
			System.out.println("actual  :" + actual.canonical());
		}
		assertEquals(expected.canonical(), actual.canonical());
	}

}
