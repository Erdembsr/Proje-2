package cis112_week02.lab;

import java.awt.Graphics;

public interface MovableInterface {

	void draw(Graphics g);

	void move();

	void setVelocity(int velocityX, int velocityY);

	BoundingBox boundingBox();

	String canonical();

}
