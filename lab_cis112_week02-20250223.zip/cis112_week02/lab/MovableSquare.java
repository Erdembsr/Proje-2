package cis112_week02.lab;

import java.awt.Color;
import java.awt.Graphics;

public class MovableSquare extends Square implements MovableInterface {

	Color color;
	int velocityX = 5;
	int velocityY = 3;

	public MovableSquare(Point pA, Point pB) {
		super(pA, pB);
	}

	@Override
	public void draw(Graphics g) {
		// below-0123456789-V toDo  // do not change this line ~~~~~~~~~~ V
		// TODO your code should be between below and above marks.


		// above-0123456789-A toDo  // do not change this line ~~~~~~~~~~ A
}

	@Override
	public void move() {
		// below-0123456789-V toDo  // do not change this line ~~~~~~~~~~ V
		// TODO your code should be between below and above marks.


		// above-0123456789-A toDo  // do not change this line ~~~~~~~~~~ A
	}

	@Override
	public void setVelocity(int velocityX, int velocityY) {
		this.velocityX = velocityX;
		this.velocityY = velocityY;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	@Override
	public String toString() {
		return "[MovableRectangle: " + boundingBox().canonical()//
				+ ", velocityX=" + velocityX + ", velocityY=" + velocityY + "color=" + color + "]";
	}

	@Override
	public String canonical() {
		return toString();
	}

}
