package cis112_week02.lab;

/**
 * Convex polygon.
 * 
 * @author bingol
 */
public abstract class Polygon {

	public abstract double getPerimeter();

	public abstract double getArea();

	public abstract BoundingBox boundingBox();

}
