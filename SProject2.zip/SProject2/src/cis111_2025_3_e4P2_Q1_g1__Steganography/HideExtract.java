package cis111_2025_3_e4P2_Q1_g1__Steganography;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * 
 * 
 * @author ruhan alpaydin
 */
public class HideExtract {

	String fileName; // name of the plain text file where
						// message (a number) will be hidden
	char hideIn; // character that will hide number's digits
	long number; // number that is going to be hidden

	private final String FILE_DIR = "/_generated/P2/";
	private final String HIDDEN_TEXT_FILE_SUFFIX = "h_";
	private final int NO_NUMBER = -1;

	/**
	 * Hides a number in a text file using steganography The method replaces
	 * sequences of the hideIn character with double occurrences to encode digits of
	 * the number
	 * 
	 * @return the name of the output file with hidden data
	 * @throws FileNotFoundException if input file doesn't exist
	 */
	public String Hide() throws FileNotFoundException {

		// below-0123456789-V toDo // do not change this line ~~~~~~~~~~ V
		// TODO your code should be between below and above marks.
		String inputPath = "." + FILE_DIR + fileName;
		String outputFileName = HIDDEN_TEXT_FILE_SUFFIX + fileName;
		String outputPath = "." + FILE_DIR + outputFileName;
		
		File inputFile = new File(inputPath);
		File outputFile = new File(outputPath);
		Scanner scanner = new Scanner(inputFile);
		
		scanner.useDelimiter(""); 
		
		PrintWriter writer = new PrintWriter(outputFile);
		String numStr = String.valueOf(number);
		
		int digitIndex = 0;
		int spaceCounter = 0;
		
		while (scanner.hasNext()) {
		String charStr = scanner.next();
			
		char c = charStr.charAt(0);
        
		if (digitIndex < numStr.length() && c == hideIn) {
				
		int currentDigit = Character.getNumericValue(numStr.charAt(digitIndex));
				
		if (spaceCounter < currentDigit) {
		
			writer.print(c);
			spaceCounter++;
		} else {		 writer.print(c); 
		                 writer.print(c);
		                 spaceCounter = 0;
							digitIndex++;
						}
					} else {writer.print(c);
					}
				}
				
				scanner.close();
				writer.close();
				return outputPath;
		// return ""; // ~~fake~~

		// above-0123456789-A toDo // do not change this line ~~~~~~~~~~ A

	}

	/**
	 * Extracts a hidden number from a text file Looks for double occurrences of the
	 * hideIn character to decode digits
	 * 
	 * @return the extracted number as a long
	 * @throws FileNotFoundException if the file doesn't exist
	 */
	public long Extract() throws FileNotFoundException {

		// below-0123456789-V toDo // do not change this line ~~~~~~~~~~ V
		// TODO your code should be between below and above marks.
		File file = new File(fileName);
		if (!file.exists()) {
			file = new File("." + FILE_DIR + fileName);
		}
		Scanner scanner = new Scanner(file);
		scanner.useDelimiter("");
		StringBuilder extractedNumStr = new StringBuilder();
		int singleSpaceCount = 0;
		boolean potentialDouble = false;
		while (scanner.hasNext()) {
			char c = scanner.next().charAt(0);

			if (c == hideIn) {
				if (potentialDouble) {extractedNumStr.append(singleSpaceCount);
				singleSpaceCount = 0;
				potentialDouble = false; 
			} else {
				potentialDouble = true;
			}
		} else {
			if (potentialDouble) {
				singleSpaceCount++;
				potentialDouble = false; 
			}
		  }
		}
		
		scanner.close();
		if (extractedNumStr.length() == 0) {
			return NO_NUMBER;
		}
		
		// String olarak biriktirdiğimiz rakamları (örn: "121") long sayıya çevir
		return Long.parseLong(extractedNumStr.toString());
		// return -314L; // ~~fake~~

		// above-0123456789-A toDo // do not change this line ~~~~~~~~~~ A

	}
}
