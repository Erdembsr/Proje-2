package cis111_2025_3_e4P2_Q1_g1__Steganography;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import org.junit.jupiter.api.Test;



class TS_HideExtract_jUnit {

	
	
	@Test
	void test_hide_short() throws IOException {
		
        HideExtract hider = new HideExtract();
        hider.fileName = "small.txt";
        hider.hideIn = ' ';
        hider.number = 13L;
        
        String hiddenFile = hider.Hide();
       
        Path fName = Path.of(hiddenFile);
        String actual = Files.readString(fName);
        
        String expected = "Omega-3 fatty  acids, primarily those found  in oily fish\n";
        
        assertEquals(expected, actual);
		
	}
	

	@Test
	void test_hide_longt() throws IOException {
		HideExtract hider = new HideExtract();
        hider.fileName = "big.txt";
        hider.hideIn = ' ';
        hider.number = 2165780000L;
        
        String hiddenFile = hider.Hide();
       
        Path fName = Path.of(hiddenFile);
        String actual = Files.readString(fName);
        
        String expected = "Omega-3 fatty acids,  primarily those  found in oily fish, "+
                "can help maintain  a healthy heart and reduce the  risk of heart disease when eaten "+
                "as part  of a healthy diet. Evidence suggests that plant sources  of  omega-3  "+
                "fatty  acids  may not have the same benefits in reducing the risk of heart disease "+
                "as those in oily fish. But you can help to ensure a balanced diet by eating rich "+
                "plant sources of omega-3 fatty acids. \n";
        
        assertEquals(expected, actual);
	}

	
	@Test
	void test_hide_short_tr() throws IOException {
		
        HideExtract hider = new HideExtract();
        hider.fileName = "turkce.txt";
        hider.hideIn = ' ';
        hider.number = 34730L;
        
        String hiddenFile = hider.Hide();
       
        Path fName = Path.of(hiddenFile);
        String actual = Files.readString(fName);
        
        String expected = "Ulusal ve uluslararası kısa  filmleri, "+
    			"arkeoloji alanına odaklanan belgeselleri,  "+
    			"henüz gösterime girmemiş filmleri, usta sinemacılar ve yazarları,  "+
    			"müzisyenleri ve koristleri Şanlıurfalılarla  buluşturuyor.  Ve tüm bunlar, "+
    			"mistik bir mekânda, Şanlıurfa’nın dar ve labirent gibi sokaklarını arşınladıktan "+
    			"sonra ulaştığınız tarihi Reji Kilisesi’nde (Vali Kemalettin Gazezoğlu Kültür ve Sanat "+
    			"Merkezi) yapılıyor.";
        
        assertEquals(expected, actual);
		
	}
	
	
	@Test
	void test_extract_short() throws FileNotFoundException {
		
		HideExtract test = new HideExtract();
		test.fileName = "small.txt";
		test.hideIn = ' ';
		test.number = 13L;

		String testFile = test.Hide();

		HideExtract testExtract = new HideExtract();
		testExtract.fileName  = testFile;
		testExtract.hideIn = ' ';

		long actual = testExtract.Extract();
		assertEquals(test.number, actual);
		
	}
	
	
	@Test
	void test_extract_longt() throws FileNotFoundException {
		
		HideExtract test = new HideExtract();
		test.fileName = "big.txt";
		test.hideIn = ' ';
		test.number = 2165780000L;

		String testFile = test.Hide();

		HideExtract testExtract = new HideExtract();
		testExtract.fileName  = testFile;
		testExtract.hideIn = ' ';

		long actual = testExtract.Extract();
		assertEquals(test.number, actual);
		
		
	}
	
}
