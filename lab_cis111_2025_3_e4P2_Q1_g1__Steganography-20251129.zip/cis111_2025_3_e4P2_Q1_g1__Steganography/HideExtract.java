package cis111_2025_3_e4P2_Q1_g1__Steganography;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * 
 * 
 * @author ruhan alpaydin
 */
public class HideExtract {

	String fileName; // name of the plain text file where
						// message (a number) will be hidden
	char hideIn; // character that will hide number's digits
	long number; // number that is going to be hidden

	private final String FILE_DIR = "/_generated/P2/";
	private final String HIDDEN_TEXT_FILE_SUFFIX = "h_";
	private final int NO_NUMBER = -1;

	/**
	 * Hides a number in a text file using steganography The method replaces
	 * sequences of the hideIn character with double occurrences to encode digits of
	 * the number
	 * 
	 * @return the name of the output file with hidden data
	 * @throws FileNotFoundException if input file doesn't exist
	 */
	public String Hide() throws FileNotFoundException {

		// below-0123456789-V toDo // do not change this line ~~~~~~~~~~ V
		// TODO your code should be between below and above marks.

		 return ""; // ~~fake~~

		// above-0123456789-A toDo // do not change this line ~~~~~~~~~~ A

	}

	/**
	 * Extracts a hidden number from a text file Looks for double occurrences of the
	 * hideIn character to decode digits
	 * 
	 * @return the extracted number as a long
	 * @throws FileNotFoundException if the file doesn't exist
	 */
	public long Extract() throws FileNotFoundException {

		// below-0123456789-V toDo // do not change this line ~~~~~~~~~~ V
		// TODO your code should be between below and above marks.

		 return -314L; // ~~fake~~

		// above-0123456789-A toDo // do not change this line ~~~~~~~~~~ A

	}
}
