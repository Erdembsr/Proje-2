package cis111_2025_3_e4P2_Q1_g1__Steganography;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * 
 * 
 * @author ruhan alpaydin
 */
public class StegoDemo {

	static String hiddenFile;
	static HideExtract hider;

	
	public static void main(String[] args) throws IOException {

		hiding();

		extracting();

		test2();

	}

	private static void hiding() throws FileNotFoundException, IOException {
		// Demonstration 1: Hide a number
		System.out.println("\n--- Hiding a number ---");
		hider = new HideExtract();
		hider.fileName = "small.txt";
		hider.hideIn = ' ';
		hider.number = 121;

		hiddenFile = hider.Hide();

		Path fName = Path.of(hiddenFile);
		System.out.println("fName=" + fName);
		String hiddenFileAsString = Files.readString(fName);
		System.out.println(hiddenFileAsString);

		String expected = "Omega-3 fatty  acids, primarily those  found in  oily fish\n";

		if (!expected.equals(hiddenFileAsString))
			System.out.println("\nHide operation is wrong\n");
		else
			System.out.println("\nHide operation is correct\n");
	}

	private static void extracting() throws FileNotFoundException {
		// Demonstration 2: Extract the number

		System.out.println("\n--- Extracting the number ---");
		HideExtract extractor = new HideExtract();
		extractor.fileName = hiddenFile; // Use the file we just created
		extractor.hideIn = ' ';

		long extractedNumber = extractor.Extract();

		// Verification
		System.out.println("\n--- Verification ---");
		System.out.println("Original number: " + hider.number);
		System.out.println("Extracted number: " + extractedNumber);
		System.out.println("Match: " + (hider.number == extractedNumber));
	}

	private static void test2() throws FileNotFoundException {
		// Additional test with different number
		System.out.println("\n--- Additional Test ---");
		HideExtract test = new HideExtract();
		test.fileName = "big.txt";
		test.hideIn = ' ';
		test.number = 456;

		String testFile = test.Hide();

		HideExtract testExtract = new HideExtract();
		testExtract.fileName = testFile;
		testExtract.hideIn = ' ';

		long testResult = testExtract.Extract();
		System.out.println("Test - Original: 456, Extracted: " + testResult + ", Match: " + (456 == testResult));
	}

}